let rotationAngle = 0;
function setup() {
  createCanvas(800, 800, WEBGL);
  // Test out the constructor function.
  let testCell = new Cell(
    createVector(1, 2, 3),
    createVector(-1, -2, -3),
    35,
    600
  );

  console.log("Testing cell:");
  console.log(testCell);

  cells = createCells(10); 
}

let img;

function preload() {
  img = loadImage('point-wave-noise-texture-abstract-dot-background-technological-cyberspace-background_1217-5375.avif'); //texture image
}

function draw() {
  background(60); // clear screen
  fill(255);
  // Draw and move cells
  for (let i = 0; i < cells.length; i++) {
    let yPos = map(cells[i].position.y, -height / 2, height / 2, 0, 1);
    let gradientColor = lerpColor(color(255, 0, 0), color(0, 0, 255), yPos); //changing the gradient for the cell colour 
    cells[i].color = gradientColor;

    cells[i].draw();
    cells[i].move();
  }

    // Push and pop to isolate transformations
    push();
    // Apply rotation only to the middle square
    rotateX(rotationAngle);
    rotateY(rotationAngle);
    drawCenterShape();
    pop();
  
    textSize(16);
    fill(255);
    textAlign(RIGHT, TOP);
    text("Cells: ")
  
  for (let i = 0; i < cells.length; i++){
    if (cells[i].getAlive() ) {
  }
  else { 
      cells.splice(i,1)
      print(cells.length)

  }
  // Collide cells
  collideCells(cells);
}
}
function drawCenterShape() {
  // Draw a rotating box at the center
  ambientLight(50); ///light on the cube
  directionalLight(250, 190, 200, 0.5, 1, -40); // direction of light on cube faces
  fill(255);
  texture(img);
  box(100);
  
  // Increment rotation angle
  rotationAngle += 0.01;
}

function Cell(position, velocity, radius, life) {
  this.position = position;
  this.velocity = velocity;
  this.radius = radius;
  this.life = life;
  this.color = color(random(255), random(255), random(255)); //colour attribute
  this.shape = 'sphere'; //shape attribute
  this.useTexture = false; // Initially, texture is not applied

  this.update = function() {
    this.move();
    this.life--;
    if (this.life <= 0) {
      this.color.setAlpha(255 * (this.life / -600)); //lower alpha based on remaining life to indicate when it will die
    }
  }

  this.toggleTexture = function () {
    this.useTexture = !this.useTexture; // Toggle texture usage
  };

  this.draw = function () {
    push(); // Save current transformation state
    translate(this.position.x, this.position.y);

    if (this.useTexture) {
      texture(img); // Apply texture if useTexture is true
    } else {
      fill(this.color); // Use fill color if useTexture is false
    }

    if (this.shape === 'sphere') {
      sphere(this.radius);
    } else if (this.shape === 'box') {
      box(this.radius);
    }
    pop(); // Restore transformation state
  };

  this.move = function () {
    this.detectEdge();
    this.position.add(this.velocity);
    this.life--;
    let direction = createVector(mouseX, mouseY).sub(this.position).normalize(); //mouse position acts a force on the cells as opposed to an object in the display
    let acceleration = direction.mult(0.038); // the multiplier to control the propelling force
    this.velocity.add(acceleration); //speed applied to cells
    this.detectEdge();
    this.position.add(this.velocity);
  };

  this.changeSpeed = function () {
    this.velocity.mult(random(0.5, 1.1)); //velocity range
  };

  this.changeSize = function () {
    this.radius = random(10, 50); // size range
  };

  this.changeShape = function () {
    if (this.shape === 'sphere') {
      this.shape = 'box';
    } else {
      this.shape = 'sphere';
    }
  };

  this.detectEdge = function () {
    let bounced = false; //hasnt bounced yet
    //checking left and right walls
    if (
      this.position.x + this.radius / 2 > width / 2 ||
      this.position.x - this.radius / 2 < -width / 2
    ) {
      this.velocity.x = -this.velocity.x;
      bounced = true; // when bounced varable is true
    }
    //Checking up and down walls
    if (
      this.position.y + this.radius / 2 > height / 2 ||
      this.position.y - this.radius / 2 < -height / 2
    ) {
      this.velocity.y = -this.velocity.y;
      bounced = true; // set to true on bounce
    }
    if (bounced) {
      this.changeColor(); // Change colour on bounce
      this.changeShape(); // change shape on bounce
      this.toggleTexture(); // change texture on bounce
    }
  };

  this.changeColor = function () {
    this.color = color(random(255), random(255), random(255)); //changes colour randomly
  };

  this.getAlive = function () {
    if (this.life < 0) { //// checks if life remains
      return false;
    }
    else {
      return true;
    }
  };
}

function createCells(n_cells) {
  let newcells = [];
  for (let i = 0; i < n_cells; i++) {
    let p = createVector(
      random(-width / 2 + 10, width / 2 - 10),
      random(-height / 2 + 10, height / 2 - 10),
      random(-200, 200)
    );
    let v = p5.Vector.random3D().mult(random(-5, 5));
    let r = round(random(15, 30));
    let l = random(200,900);
    newcells.push(new Cell(p, v, r, l)); // life is random
  }
  return newcells;
}

function collideCells(cellsArray) {
  for (let i = 0; i < cellsArray.length; i++) {
    for (let j = i + 1; j < cellsArray.length; j++) {
      let cell1 = cellsArray[i];
      let cell2 = cellsArray[j];

      let distanceVector = p5.Vector.sub(cell2.position, cell1.position);
      let distance = distanceVector.mag();
      let minDist = cell1.radius / 2 + cell2.radius / 2;

      if (distance < minDist) {
        // Calculate overlap
        let overlap = minDist - distance;

        // Reverse velocities to bounce
        cell1.velocity.mult(-1);
        cell2.velocity.mult(-1);

        cell1.changeColor(); // change colour on collision 
        cell2.changeColor();
        cell1.changeShape(); // change shape on collision
        cell2.changeShape();
        cell1.toggleTexture(); // apply or remove texture on collision
        cell2.toggleTexture();
      }
    }
  }
}
